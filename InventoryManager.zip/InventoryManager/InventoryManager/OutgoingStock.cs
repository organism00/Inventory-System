﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace InventoryManager
{
    public partial class OutgoingStock : Form
    {
        public OutgoingStock()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-QTLKQCS;Initial Catalog=INVENTORY;Integrated Security=True");
        SqlDataAdapter sda = new SqlDataAdapter();
        private void button1_Click(object sender, EventArgs e)
        {
            Dashbord db = new Dashbord();
            db.Show();
            this.Close();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            txtStockId.Text = "";
            txtStockTitle.Text = "";
            txtStockType.Text = "";
            txtQuantity.Text = "";
            dtpDate.Text = "";
            txtClearedBy.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                string Query = "INSERT INTO OutgoingStock(StockId,StockTitle,StockType,Quantity,OutgoingDate,ClearedBy)VALUES('" + txtStockId.Text + "','" + txtStockTitle.Text + "','" +
                   txtStockType.Text + "','"+txtQuantity.Text+"','" + dtpDate.Text + "','" + txtClearedBy.Text + "')";
                sda = new SqlDataAdapter(Query, conn);
                sda.SelectCommand.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Data saved successfully");
            }
            
        
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
}

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            conn.Open();
            string query = "SELECT * FROM OutgoingStock";
            sda = new SqlDataAdapter(query, conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }
    }
}
