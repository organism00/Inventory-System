﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace InventoryManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtUserName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                txtPassword.Focus();
            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                btnLogin.PerformClick();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("ARE YOU SURE YO WANT TO EXIT APPLICATION", "message", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if(string.IsNullOrEmpty(txtUserName.Text))
                {
                    MessageBox.Show("Username cannot be empty");
                    return;
                }
                if (string.IsNullOrEmpty(txtPassword.Text))
                {
                    MessageBox.Show("Password cannot be empty");
                    return;
                }

                SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-QTLKQCS;Initial Catalog=INVENTORY;Integrated Security=True");
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Admin where UserName = '" + txtUserName.Text + "' and Password = '" + txtPassword.Text + "'", conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if(dt.Rows.Count > 0)
                {
                    MessageBox.Show("You are login successfully");
                    Dashbord db = new Dashbord();
                    db.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Please Check Your Login Credentials and try again");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
